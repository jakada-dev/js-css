"""Run the local Report Compare Flask app."""

from difflib import SequenceMatcher
import re
from flask import Flask, abort, jsonify, render_template, request
from word_reader import read_word

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 150 * 1024 * 1024


@app.before_request
def check_local_request():
    # Accept requests only for the local app, including Word uploads.
    if request.host.split(':')[0] not in ('127.0.0.1', 'localhost'):
        abort(403)
    origin = request.headers.get('Origin')
    if origin and origin != request.host_url.rstrip('/'):
        abort(403)
    if request.headers.get('Sec-Fetch-Site') == 'cross-site':
        abort(403)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/read-word', methods=['POST'])
def read_document():
    # The browser sends the Word file as the request body.
    data = request.get_data()
    if not data:
        return jsonify(error='Choose a Word .docx file.'), 400
    try:
        return jsonify(html=read_word(data))
    except ValueError as error:
        # Print the reason as well as returning it to the page; the access log alone only shows 400.
        app.logger.warning('Word import rejected: %s', error)
        return jsonify(error=f'Could not read this Word file: {error}'), 400
    except Exception:
        app.logger.exception('Unexpected Word reader error')
        return jsonify(error='An unexpected Word reader error occurred. See the Flask terminal for details.'), 500


def compare_words(left, right):
    # Keep spaces as written, but compare words and punctuation rather than spacing.
    def words(text):
        if len(text) > 200000:
            raise ValueError('This section is too large. Select a smaller subsection.')
        # Browser text positions count emoji as two characters, so use UTF-16 offsets.
        offsets = [0]
        for character in text:
            offsets.append(offsets[-1] + (2 if ord(character) > 65535 else 1))
        matches = list(re.finditer(r'\w+|[^\w\s]', text))
        if len(matches) > 12000:
            raise ValueError('This section is too large. Select a smaller subsection.')
        return [match.group() for match in matches], [
            [offsets[match.start()], offsets[match.end()]] for match in matches
        ]

    left_words, left_positions = words(left)
    right_words, right_positions = words(right)
    changes = {'left': [], 'right': []}
    # Skip very common words as anchors in large sections to keep comparison responsive.
    matcher = SequenceMatcher(None, left_words, right_words,
                              autojunk=max(len(left_words), len(right_words)) > 2000)
    for action, a_start, a_end, b_start, b_end in matcher.get_opcodes():
        if action == 'equal':
            continue
        if a_start < a_end:
            changes['left'].append([left_positions[a_start][0], left_positions[a_end - 1][1]])
        if b_start < b_end:
            changes['right'].append([right_positions[b_start][0], right_positions[b_end - 1][1]])
    return changes


@app.route('/compare-sections', methods=['POST'])
def compare_sections():
    content = request.get_json(silent=True)
    if not isinstance(content, dict) or not all(isinstance(content.get(side), str) for side in ('left', 'right')):
        return jsonify(error='Choose a section in both reports to compare.'), 400
    try:
        return jsonify(compare_words(content['left'], content['right']))
    except ValueError as error:
        return jsonify(error=str(error)), 400


# FUTURE PDF: add /read-pdf here after selecting an available PDF library.
# Return text plus page numbers and positions for matching and navigation.


@app.errorhandler(413)
def file_too_large(error):
    return jsonify(error='Choose a file smaller than 150 MB.'), 413


@app.errorhandler(400)
def invalid_upload(error):
    app.logger.warning('Invalid upload request: %s', error)
    return jsonify(error='The upload request could not be read. Choose the file again and retry.'), 400


@app.after_request
def response_headers(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
    )
    return response


if __name__ == '__main__':
    # Keep this app on the current computer. Open the printed address in a browser.
    app.run(host='127.0.0.1', port=8765, debug=False)
