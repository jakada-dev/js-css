"""Read Word paragraphs and tables with Python standard-library modules."""

from html import escape
from io import BytesIO
from xml.etree import ElementTree
from zipfile import BadZipFile, ZipFile


def read_word(data):
    """Read the main Word document using only Python's standard library."""
    # Older .doc files and encrypted Office documents use this container instead of ZIP.
    if data.startswith(bytes.fromhex('D0 CF 11 E0 A1 B1 1A E1')):
        raise ValueError('This is a legacy or encrypted/protected Office container. Only ordinary .docx files are supported.')
    try:
        with ZipFile(BytesIO(data)) as archive:
            try:
                info = archive.getinfo('word/document.xml')
            except KeyError:
                raise ValueError('The file has no word/document.xml. It is not a supported Word .docx file.') from None
            if info.file_size > 30 * 1024 * 1024:
                raise ValueError('The document XML exceeds the 30 MB text limit.')
            if info.flag_bits & 1:
                raise ValueError('Encrypted ZIP entries are not supported.')
            xml = archive.read(info)
    except BadZipFile:
        raise ValueError('The file is not a readable DOCX ZIP package. It may be damaged or have the wrong extension.') from None
    if b'<!DOCTYPE' in xml.upper() or b'<!ENTITY' in xml.upper():
        raise ValueError('Unsupported XML declarations in the Word file.')
    try:
        root = ElementTree.fromstring(xml)
    except ElementTree.ParseError as error:
        raise ValueError(f'The document XML cannot be parsed: {error}') from None
    # Word can save both Transitional and Strict Open XML documents as .docx.
    word_namespace = root.tag.partition('}')[0].removeprefix('{')
    if word_namespace not in (
        'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'http://purl.oclc.org/ooxml/wordprocessingml/main',
    ) or root.tag != '{' + word_namespace + '}document':
        raise ValueError('The file uses an unsupported Word XML format.')
    namespace = {'w': word_namespace}
    prefix = '{' + namespace['w'] + '}'

    def convert(element):
        name = element.tag.removeprefix(prefix)
        if name == 'p':
            # Preserve text, line breaks, and tabs; leave Word's styling behind.
            parts = []
            for node in element.iter():
                if node.tag == prefix + 't':
                    parts.append(node.text or '')
                elif node.tag in (prefix + 'br', prefix + 'cr'):
                    parts.append('\n')
                elif node.tag == prefix + 'tab':
                    parts.append('\t')
            text = ''.join(parts)
            style = element.find('w:pPr/w:pStyle', namespace)
            value = style.get(prefix + 'val', '') if style is not None else ''
            tag = 'h' + value[-1] if value.lower() in [f'heading{i}' for i in range(1, 7)] else 'p'
            return f'<{tag}>' + escape(text).replace('\n', '<br>') + f'</{tag}>'
        if name == 'tbl':
            return '<table>' + ''.join(convert(child) for child in element) + '</table>'
        if name == 'tr':
            return '<tr>' + ''.join(convert(child) for child in element) + '</tr>'
        if name == 'tc':
            span = element.find('w:tcPr/w:gridSpan', namespace)
            count = int(span.get(prefix + 'val', '1')) if span is not None else 1
            return f'<td colspan="{max(1, min(100, count))}">' + ''.join(convert(child) for child in element) + '</td>'
        if name in ('body', 'sdt', 'sdtContent'):
            return ''.join(convert(child) for child in element)
        return ''

    body = root.find('w:body', namespace)
    if body is None:
        raise ValueError('This file has no Word document body.')
    return convert(body)


